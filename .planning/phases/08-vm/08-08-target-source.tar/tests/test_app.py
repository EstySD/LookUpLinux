"""Observable request identity, resource ownership and history invariants."""
import contextlib
import sqlite3
import threading
import time
import unittest
from unittest.mock import patch

from lookup import app, config, translate, context as contextual, ocr
from lookup.platform import Monitor
from lookup.store import open_store, get_word_context
from tests._support import make_tempdir, forbid_network
from tests.test_translate_ready import Dictionary, ANSWER

MONITOR=Monitor('public',0,0,1000,800,1)


class FixedSource:
    def __init__(self,text='word'):
        self.text=text
    def freeze(self):
        return app.Frozen('primary',(50,50),MONITOR,text=self.text)
    def resolve(self,frozen,dictset):
        return app.Query(frozen.text,frozen.text)
    def consume(self,frozen):
        pass


class EngineCase(unittest.TestCase):
    def setUp(self):
        self.root=make_tempdir(self)
        self.network=forbid_network(self)
        self.path=self.root/'history.db'
        self.events=[]
        self.event=threading.Event()
        self.owners=[]
    @contextlib.contextmanager
    def resources(self):
        self.owners.append(('open',threading.get_ident()))
        owners=self.owners
        class SpyDictionary(Dictionary):
            def find(self,key):
                owners.append(('find',threading.get_ident()))
                return super().find(key)
        conn=open_store(self.path)
        conn.execute('PRAGMA busy_timeout=50')
        try:yield app.Resources(config.Config(online=False),SpyDictionary(),conn)
        finally:
            self.owners.append(('close',threading.get_ident()))
            conn.close()
    def engine(self,source=None,lookup=None,resources=None):
        def publish(event):
            self.events.append(event)
            self.event.set()
        engine=app.Engine(publish,source=source or FixedSource(),resources=resources or self.resources,lookup=lookup)
        def close():
            engine.stop();engine.join(2)
            self.assertFalse(engine.is_alive())
        self.addCleanup(close)
        return engine
    def wait(self,predicate):
        deadline=time.monotonic()+2
        while time.monotonic()<deadline:
            self.event.clear()
            if predicate():return
            self.event.wait(.05)
        self.fail('observable engine state did not arrive')
    def count(self):
        with contextlib.closing(open_store(self.path)) as conn:
            return conn.execute('SELECT coalesce(sum(count),0) FROM words').fetchone()[0]

class EngineTests(EngineCase):
    def test_ready_and_final_count_once_on_worker_thread(self):
        engine=self.engine()
        identity=engine.begin();engine.enqueue(identity)
        self.wait(lambda:any(e.stage=='context' for e in self.events))
        self.assertEqual([e.stage for e in self.events],['frozen','ready','context'])
        self.assertEqual(self.count(),1)
        for event in self.events[1:]:
            self.assertEqual(event.result.count,1)
            self.assertTrue(event.result.saved)
        engine.stop();engine.join(2)
        self.assertEqual(len(set(owner for _,owner in self.owners)),1)
        self.assertNotEqual(self.owners[0][1],threading.get_ident())

    def test_replacement_and_dismiss_before_ready_never_write_stale_history(self):
        for dismiss in (False,True):
            with self.subTest(dismiss=dismiss):
                entered,release,completed=threading.Event(),threading.Event(),threading.Event()
                def lookup(text,**kwargs):
                    entered.set();release.wait(2)
                    value=translate.Result('word',text,translation='meaning')
                    kwargs['on_ready'](value)
                    completed.set()
                    return value
                engine=self.engine(lookup=lookup)
                first=engine.begin();engine.enqueue(first)
                self.assertTrue(entered.wait(1))
                if dismiss:engine.dismiss(first)
                else:engine.begin()
                release.set()
                self.assertTrue(completed.wait(1))
                self.assertEqual(self.count(),0)
                self.assertFalse(any(e.stage=='ready' for e in self.events))
                engine.stop();engine.join(2)
                self.events.clear()

    def test_burst_retains_only_latest_and_stale_ready_is_suppressed(self):
        entered,release=threading.Event(),threading.Event()
        calls=[]
        def lookup(text,**kwargs):
            calls.append(text)
            if len(calls)==1:
                entered.set();release.wait(2)
            result=translate.Result('word',text,translation='meaning')
            kwargs['on_ready'](result)
            return result
        engine=self.engine(lookup=lookup)
        first=engine.begin();engine.enqueue(first)
        self.assertTrue(entered.wait(1))
        for _ in range(15):
            latest=engine.begin();engine.enqueue(latest)
        release.set()
        self.wait(lambda:any(e.id==latest and e.stage=='context' for e in self.events))
        self.assertEqual(len(calls),2)
        self.assertEqual(self.count(),1)
        self.assertEqual([e.id for e in self.events if e.stage=='ready'],[latest])

    def test_real_busy_writer_preserves_answer_without_false_count(self):
        opened,go=threading.Event(),threading.Event()
        @contextlib.contextmanager
        def resources():
            with self.resources() as value:
                opened.set();go.wait(1)
                yield value
        engine=self.engine(resources=resources)
        self.assertTrue(opened.wait(1))
        other=sqlite3.connect(self.path,isolation_level=None)
        self.addCleanup(other.close)
        other.execute('BEGIN IMMEDIATE')
        identity=engine.begin();engine.enqueue(identity)
        started=time.monotonic();go.set()
        self.wait(lambda:any(e.stage=='ready' for e in self.events))
        ready=next(e for e in self.events if e.stage=='ready')
        self.assertLess(time.monotonic()-started,1)
        self.assertEqual(ready.save_error,'unavailable')
        self.assertIsNone(ready.result.count)
        self.assertFalse(ready.result.saved)
        self.assertTrue(ready.result.articles)
        other.execute('ROLLBACK')

    def test_sentence_never_creates_word_row(self):
        engine=self.engine(source=FixedSource('one two three four five'))
        identity=engine.begin();engine.enqueue(identity)
        self.wait(lambda:any(e.stage=='context' for e in self.events))
        self.assertEqual(self.count(),0)
        self.assertEqual(next(e for e in self.events if e.stage=='ready').result.kind,'sentence')

    def test_ocr_timeout_has_recognition_error_identity(self):
        from lookup import ocr
        class FailedSource(FixedSource):
            def resolve(self,*args):raise ocr.OcrError('timeout')
        engine=self.engine(source=FailedSource())
        identity=engine.begin();engine.enqueue(identity)
        self.wait(lambda:any(e.stage=='error' for e in self.events))
        self.assertEqual(next(e.error for e in self.events if e.stage=='error'),'ocr_timeout')
        self.assertEqual(self.count(),0)

    def test_quit_closes_owned_resources_while_timed_out_context_is_still_alive(self):
        entered,release=threading.Event(),threading.Event()
        self.addCleanup(release.set)
        class ContextSource(FixedSource):
            def resolve(self,frozen,dictset):
                return app.Query('word','Public source context')
        @contextlib.contextmanager
        def resources():
            with self.resources() as value:
                value.config=config.Config(online=True)
                yield value
        def network(*args,**kwargs):
            entered.set();release.wait(2)
            return ANSWER
        with patch.object(translate,'CONTEXT_JOIN_S',.02),patch.object(translate._online,'translate_online',side_effect=network) as request:
            engine=self.engine(source=ContextSource(),resources=resources)
            identity=engine.begin();engine.enqueue(identity)
            self.wait(lambda:any(e.id==identity and e.stage=='context' for e in self.events))
            self.assertTrue(entered.is_set())
            for _ in range(4):
                identity=engine.begin();engine.enqueue(identity)
                self.wait(lambda:any(e.id==identity and e.stage=='context' for e in self.events))
            self.assertEqual(request.call_count,1)
            engine.stop();engine.join(.5)
            self.assertFalse(engine.is_alive())
            self.assertEqual(self.owners[-1][0],'close')
            self.assertFalse(release.is_set())
            release.set()

    def test_contextual_enrichment_counts_once_and_stale_reply_cannot_update_pair(self):
        for stale in ('none','dismiss','replace'):
            with self.subTest(stale=stale):
                entered,release,finished=threading.Event(),threading.Event(),threading.Event()
                self.addCleanup(release.set)
                with contextlib.closing(open_store(self.path)) as conn:
                    conn.execute('DELETE FROM contextual_translations')
                source='They sat on the bank of the river.'
                class ContextSource(FixedSource):
                    def resolve(self,frozen,dictset):
                        return app.Query('bank',source,span=(16,20),context_complete=True)
                @contextlib.contextmanager
                def resources():
                    with self.resources() as value:
                        value.config=config.Config(online=True)
                        yield value
                def meaning(request):
                    entered.set();release.wait(2)
                    return contextual.ContextResult('берегу',contextual.PROVIDER)
                original=translate.lookup
                def lookup(*args,**kwargs):
                    try:return original(*args,**kwargs)
                    finally:finished.set()
                with patch.object(translate._online,'translate_online',return_value=ANSWER), \
                     patch.object(contextual,'translate_context',side_effect=meaning):
                    engine=self.engine(source=ContextSource(),resources=resources,lookup=lookup)
                    identity=engine.begin();engine.enqueue(identity)
                    self.wait(lambda:any(e.id==identity and e.stage=='ready' for e in self.events))
                    self.assertTrue(entered.is_set())
                    ready=next(e for e in self.events if e.id==identity and e.stage=='ready')
                    self.assertTrue(ready.result.meaning_pending)
                    self.assertEqual(ready.span,(16,20))
                    if stale=='dismiss':engine.dismiss(identity)
                    elif stale=='replace':engine.begin()
                    release.set();self.assertTrue(finished.wait(1))
                    if stale=='none':
                        self.wait(lambda:any(e.id==identity and e.stage=='context' for e in self.events))
                        final=next(e for e in self.events if e.id==identity and e.stage=='context')
                        self.assertEqual(final.span,(16,20))
                    else:
                        self.assertFalse(any(e.id==identity and e.stage=='context' for e in self.events))
                    engine.stop();engine.join(2)
                with contextlib.closing(open_store(self.path)) as conn:
                    pair=get_word_context(conn,'bank')
                    self.assertEqual(pair['context'],source)
                    self.assertEqual(pair['span'],(16,20))
                    self.assertEqual(pair['meaning'],'берегу' if stale=='none' else None)
                    self.assertEqual(conn.execute('SELECT count FROM words WHERE word=?',('bank',)).fetchone()[0],
                                     ('none','dismiss','replace').index(stale)+1)
                self.events.clear()

    def test_late_enrichment_error_or_unmatched_pair_has_separate_warning(self):
        class ContextSource(FixedSource):
            def resolve(self,frozen,dictset):
                return app.Query('bank','The bank by the river.',span=(4,8),context_complete=True)
        def lookup(text,**kwargs):
            value=translate.Result('word',text,translation='meaning',context_meaning='берег',
                                   meaning_provider=contextual.PROVIDER)
            kwargs['on_ready'](value)
            return value
        for error in (sqlite3.OperationalError('private detail'),None):
            with self.subTest(error=type(error).__name__):
                with patch.object(app,'enrich_word_context',side_effect=error,return_value=False):
                    engine=self.engine(source=ContextSource(),lookup=lookup)
                    identity=engine.begin();engine.enqueue(identity)
                    self.wait(lambda:any(e.id==identity and e.stage=='context' for e in self.events))
                    final=next(e for e in self.events if e.id==identity and e.stage=='context')
                    self.assertTrue(final.result.meaning_save_error)
                    self.assertTrue(final.result.saved)
                    self.assertIsNone(final.result.cache_error)
                    self.assertEqual(final.result.context_meaning,'берег')
                    engine.stop();engine.join(2)
                self.events.clear()

    def test_dismiss_after_cached_ready_keeps_the_already_shown_meaning(self):
        source='The bank by the river.'
        release,finished=threading.Event(),threading.Event()
        self.addCleanup(release.set)
        class ContextSource(FixedSource):
            def resolve(self,frozen,dictset):
                return app.Query('bank',source,span=(4,8),context_complete=True)
        @contextlib.contextmanager
        def resources():
            with self.resources() as value:
                value.config=config.Config(online=True)
                contextual.cache_put(value.conn,contextual.ContextRequest(source,4,8,'bank'),
                                     contextual.ContextResult('берег',contextual.PROVIDER))
                yield value
        def sentence(*args,**kwargs):
            release.wait(2)
            return ANSWER
        original=translate.lookup
        def lookup(*args,**kwargs):
            try:return original(*args,**kwargs)
            finally:finished.set()
        with patch.object(translate._online,'translate_online',side_effect=sentence):
            engine=self.engine(source=ContextSource(),resources=resources,lookup=lookup)
            self.addCleanup(release.set)
            identity=engine.begin();engine.enqueue(identity)
            self.wait(lambda:any(e.id==identity and e.stage=='ready' for e in self.events))
            ready=next(e for e in self.events if e.id==identity and e.stage=='ready')
            self.assertEqual(ready.result.context_meaning,'берег')
            with contextlib.closing(open_store(self.path)) as conn:
                self.assertEqual(get_word_context(conn,'bank')['meaning'],'берег')
            engine.dismiss(identity)
            release.set();self.assertTrue(finished.wait(1))
            engine.stop();engine.join(2)
        self.assertFalse(any(e.id==identity and e.stage=='context' for e in self.events))
        with contextlib.closing(open_store(self.path)) as conn:
            pair=get_word_context(conn,'bank')
            self.assertEqual((pair['context'],pair['span'],pair['meaning']),(source,(4,8),'берег'))
            self.assertEqual(conn.execute('SELECT count FROM words').fetchone()[0],1)


class ReloadTests(EngineCase):
    def test_reload_invalidates_old_lookup_and_next_uses_saved_order_online(self):
        entered,release,opened = threading.Event(),threading.Event(),threading.Event()
        self.addCleanup(release.set)
        path = self.root/'settings.json'
        config.save(dict(dictionaries=[dict(id='a'),dict(id='b')],online=True),path)
        calls,closed = [],[]
        @contextlib.contextmanager
        def resources():
            cfg = config.load(path)
            class Dictionaries:
                order = cfg.dictionaries
                def close(self):closed.append(threading.get_ident())
            dictionaries = Dictionaries()
            with self.resources() as value:
                value.config,value.dictset = cfg,dictionaries
                opened.set()
                try:yield value
                finally:dictionaries.close()
        def lookup(text,**kwargs):
            calls.append((kwargs['dictset'].order,kwargs['online']))
            if len(calls)==1:
                entered.set();release.wait(2)
            value=translate.Result('word',text,translation='meaning')
            kwargs['on_ready'](value)
            return value
        engine=self.engine(resources=resources,lookup=lookup)
        self.addCleanup(release.set)
        self.assertTrue(opened.wait(1))
        first=engine.begin();engine.enqueue(first)
        self.assertTrue(entered.wait(1))
        config.save(dict(dictionaries=[dict(id='b'),dict(id='a',enabled=False)],online=False),path)
        revision=engine.request_reload()
        latest=engine.begin();engine.enqueue(latest)
        self.assertGreater(latest,first)
        self.assertFalse(engine.current(first))
        release.set()
        self.wait(lambda:any(e.id==latest and e.stage=='context' for e in self.events))
        acknowledgement=next(e for e in self.events if e.stage=='reload')
        self.assertEqual(acknowledgement.reload_revision,revision)
        self.assertIsNone(acknowledgement.error)
        self.assertEqual(calls,[((('a',True),('b',True)),True),((('b',True),('a',False)),False)])
        self.assertEqual([e.id for e in self.events if e.stage=='ready'],[latest])
        self.assertEqual(self.count(),1)
        engine.stop();engine.join(2)
        self.assertEqual(len(closed),2)
        self.assertEqual(len(set(closed+[owner for _,owner in self.owners])),1)
        self.assertNotEqual(closed[0],threading.get_ident())

    def test_superseded_acknowledgement_has_its_own_revision_and_reload_priority(self):
        initial,opening,release=threading.Event(),threading.Event(),threading.Event()
        self.addCleanup(release.set)
        attempts=[]
        @contextlib.contextmanager
        def resources():
            attempts.append(threading.get_ident())
            if len(attempts)==2:
                opening.set();release.wait(2)
            with self.resources() as value:
                initial.set()
                yield value
        engine=self.engine(resources=resources)
        self.assertTrue(initial.wait(1))
        self.addCleanup(release.set)
        first=engine.request_reload()
        self.assertTrue(opening.wait(1))
        obsolete=engine.begin();engine.enqueue(obsolete)
        second=engine.request_reload()
        latest=engine.begin();engine.enqueue(latest)
        release.set()
        self.wait(lambda:any(e.id==latest and e.stage=='context' for e in self.events))
        acknowledgements=[e for e in self.events if e.stage=='reload']
        self.assertEqual([e.reload_revision for e in acknowledgements],[first,second])
        self.assertGreater(second,first)
        self.assertEqual([e.id for e in self.events if e.stage=='ready'],[latest])
        self.assertLess(self.events.index(acknowledgements[-1]),next(i for i,e in enumerate(self.events) if e.stage=='ready'))
        self.assertEqual(len(attempts),3)

    def test_failed_reload_is_explicit_keeps_worker_alive_and_can_retry(self):
        opened=threading.Event()
        attempts=[]
        @contextlib.contextmanager
        def resources():
            attempts.append(1)
            if len(attempts)==2:
                raise RuntimeError('private resource path')
            with self.resources() as value:
                opened.set()
                yield value
        engine=self.engine(resources=resources)
        self.assertTrue(opened.wait(1))
        revision=engine.request_reload()
        waiting=engine.begin();engine.enqueue(waiting)
        self.wait(lambda:any(e.id==waiting and e.stage=='error' for e in self.events))
        ack=next(e for e in self.events if e.stage=='reload')
        self.assertEqual((ack.reload_revision,ack.error),(revision,'reload_failed'))
        self.assertEqual(next(e.error for e in self.events if e.id==waiting and e.stage=='error'),'reload_failed')
        self.assertTrue(engine.is_alive())
        retry=engine.request_reload()
        latest=engine.begin();engine.enqueue(latest)
        self.wait(lambda:any(e.id==latest and e.stage=='context' for e in self.events))
        self.assertIsNone(next(e.error for e in self.events if e.reload_revision==retry))
        self.assertEqual(self.count(),1)
        engine.stop();engine.join(2)
        self.assertIsNone(engine.request_reload())

    def test_reload_during_meaning_refuses_old_enrichment_and_preserves_card(self):
        from lookup import learning
        source='They sat on the bank of the river.'
        entered,release,finished=threading.Event(),threading.Event(),threading.Event()
        self.addCleanup(release.set)
        class ContextSource(FixedSource):
            def resolve(self,frozen,dictset):
                return app.Query('bank',source,span=(16,20),context_complete=True)
        def meaning(request):
            entered.set();release.wait(2)
            return contextual.ContextResult('берег',contextual.PROVIDER)
        original=translate.lookup
        def lookup(*args,**kwargs):
            try:return original(*args,**kwargs)
            finally:finished.set()
        @contextlib.contextmanager
        def resources():
            with self.resources() as value:
                value.config=config.Config(online=True)
                yield value
        with patch.object(translate._online,'translate_online',return_value=ANSWER), \
             patch.object(contextual,'translate_context',side_effect=meaning):
            engine=self.engine(source=ContextSource(),resources=resources,lookup=lookup)
            self.addCleanup(release.set)
            identity=engine.begin();engine.enqueue(identity)
            self.wait(lambda:any(e.id==identity and e.stage=='ready' for e in self.events))
            self.assertTrue(entered.is_set())
            with contextlib.closing(open_store(self.path)) as conn:
                learning.add_history_card(conn,'bank',now=1)
                card=learning.get_card(conn,'bank')
            revision=engine.request_reload()
            release.set();self.assertTrue(finished.wait(1))
            self.wait(lambda:any(e.stage=='reload' and e.reload_revision==revision for e in self.events))
            self.assertFalse(any(e.id==identity and e.stage=='context' for e in self.events))
            with contextlib.closing(open_store(self.path)) as conn:
                self.assertIsNone(get_word_context(conn,'bank')['meaning'])
                self.assertEqual(learning.get_card(conn,'bank'),card)
                self.assertEqual(conn.execute('SELECT count FROM words').fetchone()[0],1)

    def test_partial_resource_errors_cannot_report_settings_applied(self):
        for error_field in ('reload_error','save_error'):
            with self.subTest(error_field=error_field):
                opened=threading.Event()
                attempts=[]
                @contextlib.contextmanager
                def resources():
                    attempts.append(1)
                    with self.resources() as value:
                        if len(attempts)==2:
                            setattr(value,error_field,'unavailable')
                        opened.set()
                        yield value
                engine=self.engine(resources=resources)
                self.assertTrue(opened.wait(1))
                revision=engine.request_reload()
                self.wait(lambda:any(e.reload_revision==revision for e in self.events))
                self.assertEqual(next(e.error for e in self.events if e.reload_revision==revision),'reload_failed')
                engine.stop();engine.join(2)
                self.assertFalse(engine.is_alive())
                self.events.clear()


class SourceTests(unittest.TestCase):
    def test_recovered_context_and_selected_phrase_span_are_propagated(self):
        from types import SimpleNamespace
        text='The river bank by the bank.'
        selection=ocr.Selection('bank','original line',('river bank',),(10,10,20,10),90,
                                text,(10,14),True,(('river bank',(4,14)),))
        frame=SimpleNamespace(width=1000,height=800,png=b'public',elapsed_ms=1)
        frozen=app.Frozen('ocr',(20,20),MONITOR,image=frame)
        with patch.object(ocr,'recognize_image',return_value=SimpleNamespace(selection=selection,timings={})), \
             patch.object(ocr,'choose_query',return_value='river bank'):
            query=app.Source({}).resolve(frozen,None)
        self.assertEqual(query.context,text)
        self.assertEqual(query.span,(4,14))
        self.assertTrue(query.context_complete)

    def test_fresh_repeated_absent_invalid_primary_transitions(self):
        source=app.Source({})
        frames=object()
        with patch('lookup.app.platform.cursor_position',return_value=(50,50)), \
             patch('lookup.app.platform.monitors',return_value=(MONITOR,)), \
             patch('lookup.app.platform.work_area',return_value=(0,0,1000,750)), \
             patch('lookup.app.platform.read_primary',side_effect=['Word','Word',None,'Word','\x00bad','word '*251]), \
             patch('lookup.app.capture.capture_monitor',return_value=frames) as screenshot:
            states=[]
            for _ in range(6):
                frozen=source.freeze()
                states.append(frozen)
                source.consume(frozen)
        self.assertEqual([s.mode for s in states],['primary','ocr','ocr','primary','ocr','ocr'])
        self.assertEqual(screenshot.call_count,4)
        self.assertEqual(states[0].text,'Word')
        self.assertEqual(states[0].available,(0,0,1000,750))

    def test_unaccepted_source_is_not_marked_already_translated(self):
        source=app.Source({})
        with patch('lookup.app.platform.cursor_position',return_value=(50,50)), \
             patch('lookup.app.platform.monitors',return_value=(MONITOR,)), \
             patch('lookup.app.platform.work_area',return_value=(0,0,1000,750)), \
             patch('lookup.app.platform.read_primary',return_value='Word'), \
             patch('lookup.app.capture.capture_monitor') as screenshot:
            first=source.freeze()
            second=source.freeze()
            self.assertEqual((first.mode,second.mode),('primary','primary'))
            source.consume(second)
            self.assertEqual(source.freeze().mode,'ocr')
            self.assertEqual(screenshot.call_count,1)


if __name__=='__main__':
    unittest.main()
